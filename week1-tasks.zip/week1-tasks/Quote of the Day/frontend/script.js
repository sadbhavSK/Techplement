document.addEventListener("DOMContentLoaded", () => {
  const quoteElement = document.getElementById("quote");
  const authorElement = document.getElementById("author");
  const newQuoteButton = document.getElementById("new-quote");
  const searchForm = document.getElementById("search-form");
  const authorInput = document.getElementById("author-name");
  const resultsContainer = document.getElementById("results");

  const API_BASE_URL = "http://localhost:5000/api";

  // Fetch and display a random quote
  async function fetchRandomQuote() {
    try {
      const response = await fetch(`${API_BASE_URL}/random-quote`);
      const data = await response.json();
      quoteElement.innerText = `"${data.content}"`;
      authorElement.innerText = `- ${data.author}`;
    } catch (error) {
      console.error("Error fetching random quote:", error);
    }
  }

  // Fetch quotes by author and display results
  async function searchQuotesByAuthor(author) {
    try {
      const response = await fetch(`${API_BASE_URL}/quotes/${author}`);
      const data = await response.json();

      resultsContainer.innerHTML = ""; // Clear previous results

      if (data.length === 0) {
        resultsContainer.innerHTML = "<p>No quotes found for this author.</p>";
      } else {
        data.forEach((quote) => {
          const quoteDiv = document.createElement("div");
          quoteDiv.classList.add("result-quote");

          quoteDiv.innerHTML = `
            <p>"${quote.content}"</p>
            <p class="result-author">- ${quote.author}</p>
          `;

          resultsContainer.appendChild(quoteDiv);
        });
      }
    } catch (error) {
      console.error("Error fetching quotes by author:", error);
    }
  }

  // Event listeners
  newQuoteButton.addEventListener("click", fetchRandomQuote);

  searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const author = authorInput.value.trim();
    if (author) {
      searchQuotesByAuthor(author);
    }
  });

  // Fetch a random quote on page load
  fetchRandomQuote();
});
