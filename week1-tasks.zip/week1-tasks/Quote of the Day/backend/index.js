const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Welcome to the Quote API!");
});

// Fetch Random Quote
app.get("/api/random-quote", (req, res) => {
  const sql = "SELECT * FROM quotes ORDER BY RAND() LIMIT 1";
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.json(result[0]);
  });
});

// Search Quotes by Author
app.get("/api/quotes/:author", (req, res) => {
  const author = req.params.author;
  const sql = "SELECT * FROM quotes WHERE author LIKE ?";
  db.query(sql, [`%${author}%`], (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
